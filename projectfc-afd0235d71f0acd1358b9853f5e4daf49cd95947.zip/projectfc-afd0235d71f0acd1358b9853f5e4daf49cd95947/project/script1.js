document.getElementById('getStartedBtn').addEventListener('click', function() {
    window.location.href = 'html2.html'; // Replace with your actual target page link
});
